based on   https://github.com/klausharbo/clojupyter-docker/tree/master/clojupyter-base
