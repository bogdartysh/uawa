;; gorilla-repl.fileformat = 1

;; **
;;; # Uawa
;; **

;; @@
(use 'uawa.core)
;; @@
;; =>
;;; {"type":"html","content":"<span class='clj-nil'>nil</span>","value":"nil"}
;; <=

;; @@
(ціна ціна-груші 100 грн)
(функція розрахуй-вартість [ціна-за-єдиницю кількість] (домнож ціна-за-єдиницю кількість))
(друкуй (розрахуй-вартість ціна-груші 10))
;; @@
;; ->
;;; 1000 UAH
;;;
;; <-
;; =>
;;; {"type":"html","content":"<span class='clj-nil'>nil</span>","value":"nil"}
;; <=

;; @@

;; @@
